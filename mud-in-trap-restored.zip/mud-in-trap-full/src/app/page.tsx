
'use client';

import type { FormEvent } from 'react';
import { useEffect, useMemo, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

type TrackStatus = 'done' | 'in-progress' | 'coming-soon';

type Track = {
  id: number;
  title?: string | null;
  name?: string | null;
  status?: string | null;
  // DB may also store `track_title` etc. We keep this loose and normalize below.
  [k: string]: any;
};

type Post = {
  id: number;
  image_url?: string | null;
  url?: string | null;
  caption?: string | null;
  visibility?: string | null;
  created_at?: string | null;
  [k: string]: any;
};

const fallbackTracks: Array<{ id: number; title: string; name: string; status: TrackStatus }> = [
  { id: 1, title: 'TRACK 1', name: 'CHEVY 1', status: 'done' },
  { id: 2, title: "TIMMY'S", name: 'TURN', status: 'in-progress' },
  { id: 3, title: 'COLLAB', name: 'TRACK', status: 'coming-soon' },
];

// Social links
const socials = [
  { name: 'Instagram', icon: '📸', url: 'https://www.instagram.com/_d_roc_' },
  { name: 'TikTok', icon: '🎵', url: 'https://www.tiktok.com/@big.droc' },
  { name: 'YouTube', icon: '▶️', url: 'https://youtube.com/@bigdroc' },
  { name: 'Spotify', icon: '🎧', url: '#' },
];

export default function Home() {
  const [activeSection, setActiveSection] = useState('home');

  // Email subscribe
  const [email, setEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [emailMsg, setEmailMsg] = useState<string>('');
  const [emailMsgTone, setEmailMsgTone] = useState<'muted' | 'good' | 'bad'>('muted');

  // Content from DB
  const [dbTracks, setDbTracks] = useState<Track[] | null>(null);
  const [dbPosts, setDbPosts] = useState<Post[] | null>(null);
  const [loadError, setLoadError] = useState<string>('');

  const normalizedTracks = useMemo(() => {
    const src = (dbTracks && dbTracks.length > 0) ? dbTracks : fallbackTracks;
    return src.map((t: any, i: number) => {
      const title = (t.title ?? t.track_title ?? t.label ?? fallbackTracks[i]?.title ?? `TRACK ${i + 1}`) as string;
      const name = (t.name ?? t.track_name ?? t.song ?? fallbackTracks[i]?.name ?? 'TBD') as string;
      const rawStatus = String(t.status ?? fallbackTracks[i]?.status ?? 'coming-soon').toLowerCase();
      const status: TrackStatus = rawStatus.includes('done') || rawStatus.includes('released') ? 'done'
        : rawStatus.includes('progress') || rawStatus.includes('work') ? 'in-progress'
        : 'coming-soon';
      return { id: Number(t.id ?? i + 1), title, name, status };
    });
  }, [dbTracks]);

  const visiblePosts = useMemo(() => {
    const src = dbPosts ?? [];
    return src
      .filter(p => (p.visibility ?? 'public') === 'public')
      .slice(0, 8);
  }, [dbPosts]);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoadError('');
      try {
        const [{ data: tracks, error: tracksError }, { data: posts, error: postsError }] = await Promise.all([
          supabase.from('tracks').select('*').order('id', { ascending: true }),
          supabase.from('posts').select('*').order('created_at', { ascending: false }),
        ]);

        if (!cancelled) {
          if (tracksError) setLoadError(tracksError.message);
          if (postsError) setLoadError((prev) => prev ? `${prev} | ${postsError.message}` : postsError.message);
          setDbTracks(tracks ?? null);
          setDbPosts(posts ?? null);
        }
      } catch (e: any) {
        if (!cancelled) setLoadError(e?.message ?? 'Failed to load content.');
      }
    }

    load();
    return () => { cancelled = true; };
  }, []);

  async function onSubscribe(e: FormEvent) {
    e.preventDefault();
    setEmailMsg('');
    setEmailMsgTone('muted');

    const value = email.trim();
    if (!value) {
      setEmailMsgTone('bad');
      setEmailMsg('Put an email in the box.');
      return;
    }

    setSubmitting(true);
    try {
      const { error } = await supabase.from('subscribers').insert([{ email: value }]);
      if (error) {
        setEmailMsgTone('bad');
        setEmailMsg(error.message);
      } else {
        setEmailMsgTone('good');
        setEmailMsg('You are in. Welcome to the swamp.');
        setEmail('');
      }
    } catch (e: any) {
      setEmailMsgTone('bad');
      setEmailMsg(e?.message ?? 'Subscription failed.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen waterfall-section">
      {/* Animated Background Overlay */}
      <div 
        className="fixed inset-0 pointer-events-none opacity-30"
        style={{
          background: `
            repeating-linear-gradient(
              180deg,
              transparent 0px,
              rgba(168, 85, 247, 0.03) 2px,
              transparent 4px
            )
          `,
          animation: 'waterfall-flow 3s linear infinite',
        }}
      />

      {/* Header */}
      <header className="relative z-10 py-6 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Logo */}
          <div className="text-center mb-6">
            <h1 
              className="text-4xl md:text-6xl font-bold tracking-wider"
              style={{ 
                color: 'var(--gold)',
                textShadow: '0 0 30px rgba(168, 85, 247, 0.4), 2px 2px 0 var(--gold-dark)'
              }}
            >
              MUD <span style={{ fontSize: '0.6em', verticalAlign: 'middle' }}>IN</span> TRAP
            </h1>
            <p className="text-sm tracking-[0.3em] mt-2" style={{ color: 'var(--gold-dark)' }}>
              Country Meets Trap
            </p>
          </div>

          {/* Navigation */}
          <nav className="flex justify-center gap-2 md:gap-8 flex-wrap">
            {['HOME', 'RELEASES', 'VIP ACCESS', 'STUDIO'].map((item) => (
              <button
                key={item}
                onClick={() => setActiveSection(item.toLowerCase())}
                className="px-3 py-2 text-sm tracking-wider transition-all hover:text-purple-400"
                style={{ 
                  color: activeSection === item.toLowerCase() ? 'var(--purple-light)' : 'var(--gold-light)',
                  borderBottom: activeSection === item.toLowerCase() ? '2px solid var(--purple-glow)' : '2px solid transparent'
                }}
              >
                {item}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative z-10 py-12 px-4 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 
            className="text-3xl md:text-5xl font-bold mb-4 text-glow-purple"
            style={{ color: 'var(--text-primary)' }}
          >
            WELCOME TO THE SWAMP
          </h2>
          <p className="text-lg md:text-xl mb-8" style={{ color: 'var(--text-secondary)' }}>
            Behind The Scenes of the Music
          </p>

          {/* Current Track Display */}
          <div className="flex flex-col md:flex-row justify-center gap-4 md:gap-12 mb-8">
            <div className="glass-panel px-6 py-3 rounded">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>CURRENT TRACK:</span>
              <span className="ml-2 font-semibold" style={{ color: 'var(--gold-light)' }}>LOCK "CHEVY 1"</span>
            </div>
            <div className="glass-panel px-6 py-3 rounded">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>NEXT UP:</span>
              <span className="ml-2 font-semibold" style={{ color: 'var(--gold-light)' }}>TIMMY'S SOLO</span>
            </div>
          </div>

          {/* Email capture */}
          <form onSubmit={onSubscribe} className="max-w-xl mx-auto">
            <div className="flex flex-col md:flex-row gap-3 justify-center">
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                type="email"
                placeholder="Enter your email"
                className="glass-panel px-4 py-3 rounded w-full"
                style={{ border: '1px solid rgba(168, 85, 247, 0.35)' }}
                required
              />
              <button
                type="submit"
                className="btn-swamp btn-vip"
                disabled={submitting}
                style={{ opacity: submitting ? 0.7 : 1 }}
              >
                {submitting ? '...': 'JOIN THE CREW'}
              </button>
            </div>
            <div
              className="text-sm mt-3"
              style={{
                color:
                  emailMsgTone === 'good' ? 'var(--purple-light)' :
                  emailMsgTone === 'bad' ? '#ff4d4d' :
                  'var(--text-secondary)'
              }}
            >
              {emailMsg || (loadError ? `Content load issue: ${loadError}` : ' ')}
            </div>
          </form>
        </div>
      </section>

      <div className="section-divider my-8" />

      {/* Season Roadmap & VIP Section */}
      <section className="relative z-10 py-12 px-4">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8">
          
          {/* Season Roadmap */}
          <div className="glass-panel p-6 rounded-lg">
            <h3 
              className="text-xl md:text-2xl font-bold text-center mb-6"
              style={{ color: 'var(--gold)' }}
            >
              ✦ THE SEASON ROADMAP ✦
            </h3>
            
            <div className="flex justify-center gap-3 md:gap-4 flex-wrap mb-6">
              {normalizedTracks.map((track) => (
                <div 
                  key={track.id}
                  className={`track-card ${track.status}`}
                >
                  <div className="text-xs tracking-wider mb-1" style={{ color: 'var(--text-muted)' }}>
                    {track.title}
                  </div>
                  <div className="font-bold text-sm" style={{ color: 'var(--gold-light)' }}>
                    {track.name}
                  </div>
                  <div 
                    className="text-xs mt-2 uppercase tracking-wider"
                    style={{ 
                      color: track.status === 'done' ? 'var(--purple-light)' : 
                             track.status === 'in-progress' ? 'var(--gold)' : 'var(--text-muted)'
                    }}
                  >
                    {track.status === 'done' ? 'DONE' : 
                     track.status === 'in-progress' ? 'IN PROGRESS' : 'COMING SOON'}
                  </div>
                </div>
              ))}
            </div>

            <div className="text-center">
              <button className="btn-swamp">VIEW ALL TRACKS</button>
            </div>
          </div>

          {/* VIP Access */}
          <div className="glass-panel p-6 rounded-lg glow-purple">
            <h3 
              className="text-xl md:text-2xl font-bold text-center mb-4"
              style={{ color: 'var(--purple-light)' }}
            >
              VIP ACCESS
            </h3>
            <p className="text-center mb-6 text-sm tracking-wider" style={{ color: 'var(--text-secondary)' }}>
              EARLY DROPS • EXCLUSIVE DEMOS
            </p>
            
            <div className="space-y-4 mb-6">
              <div className="flex items-center gap-3 text-sm" style={{ color: 'var(--text-primary)' }}>
                <span className="text-purple-400">✓</span> Behind-the-scenes content
              </div>
              <div className="flex items-center gap-3 text-sm" style={{ color: 'var(--text-primary)' }}>
                <span className="text-purple-400">✓</span> Early access to new tracks
              </div>
              <div className="flex items-center gap-3 text-sm" style={{ color: 'var(--text-primary)' }}>
                <span className="text-purple-400">✓</span> Exclusive freestyles & demos
              </div>
              <div className="flex items-center gap-3 text-sm" style={{ color: 'var(--text-primary)' }}>
                <span className="text-purple-400">✓</span> Vote on upcoming content
              </div>
            </div>

            <div className="text-center">
              <button className="btn-swamp btn-vip">JOIN THE CREW</button>
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider my-8" />

      {/* Photo & Lyric Wall */}
      <section className="relative z-10 py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <h3 
            className="text-xl md:text-2xl font-bold text-center mb-8"
            style={{ color: 'var(--gold)' }}
          >
            PHOTO & LYRIC WALL
          </h3>

          <div className="flex justify-center gap-4 mb-6 flex-wrap">
            {visiblePosts.length === 0 ? (
              <>
                <div className="photo-thumb">📷</div>
                <div className="photo-thumb">🎤</div>
                <div className="photo-thumb">📝</div>
                <div className="photo-thumb">🎸</div>
              </>
            ) : (
              visiblePosts.map((p) => (
                <a
                  key={p.id}
                  href={p.image_url || p.url || '#'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="photo-thumb overflow-hidden"
                  title={p.caption || 'Post'}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={(p.image_url || p.url) as string}
                    alt={p.caption || 'Post'}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    loading="lazy"
                  />
                </a>
              ))
            )}
          </div>

          <div className="text-center">
            <button className="btn-swamp">ENTER NOW</button>
          </div>
        </div>
      </section>

      <div className="section-divider my-8" />

      {/* Studio Section (Admin) */}
      <section className="relative z-10 py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <h3 
            className="text-xl md:text-2xl font-bold text-center mb-8"
            style={{ color: 'var(--gold)' }}
          >
            THE STUDIO
          </h3>

          <div className="flex justify-center gap-3 md:gap-4 flex-wrap">
            <button className="btn-swamp">
              <span className="mr-2">✦</span>ADD UPDATE<span className="ml-2">✦</span>
            </button>
            <button className="btn-swamp">
              <span className="mr-2">✦</span>UPLOAD FILE<span className="ml-2">✦</span>
            </button>
            <button className="btn-swamp">
              <span className="mr-2">✦</span>VOTE NOW<span className="ml-2">✦</span>
            </button>
          </div>
        </div>
      </section>

      <div className="section-divider my-8" />

      {/* Footer with Social Links */}
      <footer className="relative z-10 py-12 px-4 text-center">
        <div className="max-w-4xl mx-auto">
          {/* Social Icons */}
          <div className="flex justify-center gap-6 mb-8">
            {socials.map((social) => (
              <a
                key={social.name}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110"
                style={{ 
                  background: 'var(--bg-cave)',
                  border: '2px solid var(--gold-dark)'
                }}
                title={social.name}
              >
                <span className="text-xl">{social.icon}</span>
              </a>
            ))}
          </div>

          {/* Brand */}
          <p className="text-sm tracking-wider mb-2" style={{ color: 'var(--text-muted)' }}>
            DADDY FREQUENCY PRODUCTIONS
          </p>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
            © 2025 MUD IN TRAP. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
